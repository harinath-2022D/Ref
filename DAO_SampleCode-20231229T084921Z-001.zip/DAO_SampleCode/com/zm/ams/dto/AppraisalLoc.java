package com.zm.ams.dto;

public class AppraisalLoc {
	private int locId;
	private String state;
	private String city;
	
	// constructors / standard setters / getters
}
