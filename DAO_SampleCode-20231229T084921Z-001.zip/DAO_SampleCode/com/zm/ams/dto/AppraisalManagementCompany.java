package com.zm.ams.dto;

public class AppraisalManagementCompany {
	private int amcId;
	private int amcRegId;
	//... other attributes based on the Db Entity ams.amc
	
	// constructors / standard setters / getters
}
