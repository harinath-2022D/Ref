package com.zm.ams.dto;

/*
 * Marker interface for various search criteria of AMS Application
 */
public interface SearchCriteria {

}
